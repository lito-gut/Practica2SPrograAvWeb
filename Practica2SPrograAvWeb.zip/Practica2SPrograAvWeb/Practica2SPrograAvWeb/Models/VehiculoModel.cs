using System.ComponentModel.DataAnnotations;

namespace Practica2SPrograAvWeb.Models
{
    public class VehiculoModel
    {
        [Required(ErrorMessage = "Campo obligatorio")]
        public string? Marca { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        public string? Modelo { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        public string? Color { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Debe ingresar un precio v�lido")]
        public decimal Precio { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [Display(Name = "ID del Vendedor")]
        public long IdVendedor { get; set; }
    }
}