﻿namespace Practica2SPrograAvWeb.Models
{
    public class Vehiculo
    {
        public long IdVehiculo { get; set; }

        public string? Marca { get; set; }

        public string? Modelo { get; set; }

        public string? Color { get; set; }

        public decimal Precio { get; set; }

        // Relación con Vendedor
        public long IdVendedor { get; set; }
        public Vendedor Vendedor { get; set; } = default!;
    }
}