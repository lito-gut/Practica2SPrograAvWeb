namespace Practica2SPrograAvWeb.Models
{
    public class ConsultaModel
    {
        public string? Cedula { get; set; }

        public string? Nombre { get; set; }

        public string? Marca { get; set; }

        public string? Modelo { get; set; }

        public decimal Precio { get; set; }
    }
}