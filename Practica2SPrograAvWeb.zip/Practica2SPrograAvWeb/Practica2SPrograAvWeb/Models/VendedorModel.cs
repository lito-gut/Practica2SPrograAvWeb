using System.ComponentModel.DataAnnotations;

namespace Practica2SPrograAvWeb.Models
{
    public class VendedorModel
    {
        [Required(ErrorMessage = "Campo obligatorio")]
        public string? Cedula { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        public string? Nombre { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        [EmailAddress(ErrorMessage = "Debe ingresar un correo v�lido")]
        public string? Correo { get; set; }

        [Required(ErrorMessage = "Campo obligatorio")]
        public bool Estado { get; set; } = true;
    }
}