﻿// Data/DapperService.cs
using System.Data;
using Microsoft.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace Practica2SPrograAvWeb.Data
{
    public class DapperService
    {
        private readonly IConfiguration _config;
        private readonly string _connectionString = default!;

        public DapperService(IConfiguration config)
        {
            _config = config;
            _connectionString = _config.GetConnectionString("ConexionBase")!;
        }

        public IDbConnection GetConnection()
            => new SqlConnection(_connectionString);
    }
}