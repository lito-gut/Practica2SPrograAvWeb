using Dapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc.Rendering;
using Practica2SPrograAvWeb.Data;
using Practica2SPrograAvWeb.Models;
using System.Data;
using System.Diagnostics;
using System.Linq;

namespace Practica2SPrograAvWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DapperService _dapper;


        public HomeController(ILogger<HomeController> logger, DapperService dapper)
        {
            _logger = logger;
            _dapper = dapper;

        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Inicio()
        {
            return View();
        }

        // ----------- VENDEDOR -----------
        [HttpGet]
        public IActionResult RegistroVendedor()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RegistroVendedor(VendedorModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            using var db = _dapper.GetConnection();

            // Verificar si ya existe la c�dula
            var existe = db.ExecuteScalar<bool>("sp_VerificarVendedor",
                new { Cedula = model.Cedula },
                commandType: CommandType.StoredProcedure);

            if (existe)
            {
                ModelState.AddModelError("Cedula", "Ya existe un vendedor registrado con esta c�dula.");
                return View(model); //Muestra el mensaje en el formulario
            }

            var parameters = new DynamicParameters();
            parameters.Add("@Cedula", model.Cedula);
            parameters.Add("@Nombre", model.Nombre);
            parameters.Add("@Correo", model.Correo);
            parameters.Add("@Estado", model.Estado);

            db.Execute("sp_InsertarVendedor", parameters, commandType: CommandType.StoredProcedure);

            return RedirectToAction("Inicio");
        }


        // ----------- VEH�CULO -----------
        [HttpGet]
        public IActionResult RegistroVehiculo()
        {
            CargarListaVendedores();
            return View();
        }

        [HttpPost]
        public IActionResult RegistroVehiculo(VehiculoModel model)
        {
            if (!ModelState.IsValid)
            {
                CargarListaVendedores();
                return View(model);
            }
                

            // Verificar l�mite de veh�culos por marca
            using var db = _dapper.GetConnection();

            int conteo = db.ExecuteScalar<int>("sp_ContarVehiculosPorMarca",
                new { Marca = model.Marca },
                commandType: CommandType.StoredProcedure);

            if (conteo >= 2)
            {
                ModelState.AddModelError("Marca", "No se pueden registrar m�s de 2 veh�culos de la misma marca.");
                CargarListaVendedores();
                return View(model);
            }

            // Configurar par�metros
            var parameters = new DynamicParameters();
            parameters.Add("@Marca", model.Marca);
            parameters.Add("@Modelo", model.Modelo);
            parameters.Add("@Color", model.Color);
            parameters.Add("@Precio", model.Precio);
            parameters.Add("@IdVendedor", model.IdVendedor);

            // Ejecutar procedimiento almacenado
            db.Execute("sp_InsertarVehiculo", parameters, commandType: CommandType.StoredProcedure);

            return RedirectToAction("Inicio");
        }
        private void CargarListaVendedores()
        {
            using var db = _dapper.GetConnection();
            var vendedores = db.Query<Vendedor>("sp_ObtenerIdsVendedores", commandType: CommandType.StoredProcedure).ToList();

            ViewBag.ListaVendedores = vendedores.Select(v => new SelectListItem
            {
                Text = $"{v.Nombre} (ID {v.IdVendedor})",
                Value = v.IdVendedor.ToString()
            }).ToList();
        }


        // ----------- CONSULTA -----------
        public IActionResult ConsultaVehiculo()
        {
            using var db = _dapper.GetConnection();
            var resultado = db.Query<ConsultaModel>("sp_ConsultarVehiculos", commandType: CommandType.StoredProcedure).ToList();
            return View(resultado);
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier
            });
        }
    }
}